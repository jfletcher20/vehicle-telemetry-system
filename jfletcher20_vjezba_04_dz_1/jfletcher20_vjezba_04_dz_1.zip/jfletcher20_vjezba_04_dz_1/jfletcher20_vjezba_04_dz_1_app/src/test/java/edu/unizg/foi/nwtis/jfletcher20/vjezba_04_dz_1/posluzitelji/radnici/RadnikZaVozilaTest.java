package edu.unizg.foi.nwtis.jfletcher20.vjezba_04_dz_1.posluzitelji.radnici;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;

/**
 * Testovi za radnika za vozila.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RadnikZaVozilaTest {



}
