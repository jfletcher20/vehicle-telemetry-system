package edu.unizg.foi.nwtis.konfiguracije;

import unizg.foi.nwtis.konfiguracije.KonfiguracijaTxt;

public class KonfiguracijaApstraktnaImpl extends KonfiguracijaTxt {

  public KonfiguracijaApstraktnaImpl(String nazivDatoteke) {
    super(nazivDatoteke);
  }

}

