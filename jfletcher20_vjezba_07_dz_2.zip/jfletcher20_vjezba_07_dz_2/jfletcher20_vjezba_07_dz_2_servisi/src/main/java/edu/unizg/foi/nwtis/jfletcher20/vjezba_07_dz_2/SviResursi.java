/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package edu.unizg.foi.nwtis.jfletcher20.vjezba_07_dz_2;

import jakarta.inject.Inject;


/**
 * RPodrška za REST web servise
 *
 * @author Dragutin Kermek
 */
public abstract class SviResursi {
  @Inject
  protected VezaBazaPodataka vezaBazaPodataka;

}
