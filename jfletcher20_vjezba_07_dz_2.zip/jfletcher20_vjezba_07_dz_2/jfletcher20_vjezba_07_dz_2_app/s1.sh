#!/bin/bash

# CentralniSustav server
java -cp target/jfletcher20_vjezba_07_dz_2_app-1.1.0.jar edu.unizg.foi.nwtis.jfletcher20.vjezba_07_dz_2.posluzitelji.CentralniSustav NWTiS_DZ1_CS.txt

