#! /bin/bash
./zaustaviJVMProces.sh SimulatorVozila
./zaustaviJVMProces.sh CentralniSustav
./zaustaviJVMProces.sh PosluziteljRadara
./zaustaviJVMProces.sh PosluziteljKazni
