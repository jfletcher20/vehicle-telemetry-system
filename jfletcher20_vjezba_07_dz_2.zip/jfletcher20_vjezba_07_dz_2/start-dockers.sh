#!/bin/bash

docker start nwtis_servisi_c
docker start nwtis_app_c
#docker start nwtis_h2_i
docker start nwtis_hsql_c
