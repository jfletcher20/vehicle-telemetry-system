cd /opt/payara6-web/glassfish/bin && ./startserv
