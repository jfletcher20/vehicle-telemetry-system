module jfletcher20_vjezba_07_dz_2_lib_konfig {
  exports edu.unizg.foi.nwtis.konfiguracije;
  requires com.google.gson;
}
